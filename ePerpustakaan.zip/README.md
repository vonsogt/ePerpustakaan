<p align="center"><img src="https://user-images.githubusercontent.com/35516476/80088996-79dfa300-8587-11ea-9271-84e36658ce51.png" width="400"></p>

## Tentang ePerpustakaan

ePerpustakaan merupakan aplikasi perpustakaan yang dapat mengakses [ePerpustakaan-admin](https://github.com/vonsogt/ePerpustakaan-admin) menggunakan smartphone dimana saja dan kapan saja dengan menggunakan SATU DATABASE yang sama

## Cara menginstall

- Soon

## Dokumentasi

- Soon

## Kerentanan Keamanan

Jika Anda menemukan kerentanan keamanan dalam ePerpustakaan-admin ini, silakan kirim e-mail ke Alvonso [vonsogt18081999@gmail.com](mailto:vonsogt18081999@gmail.com). Semua kerentanan keamanan akan segera ditangani.

## Lisensi

ePerpustakaan ini adalah open source website dibawah [MIT license](https://opensource.org/licenses/MIT).
